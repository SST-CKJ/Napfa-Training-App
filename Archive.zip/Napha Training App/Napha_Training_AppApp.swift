//
//  Napha_Training_AppApp.swift
//  Napha Training App
//
//  Created by Kui Jun on 24/5/24.
//

import SwiftUI

@main
struct Napha_Training_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
