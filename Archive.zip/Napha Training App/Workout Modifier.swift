//
//  Workout Modifier.swift
//  Napha Training App
//
//  Created by Kui Jun on 15/7/24.
//

import SwiftUI

struct Workout_Modifier: View {
    var body: some View {
//        Picker("random", selection: []){
//            ForEach(grades, id: \.self){ grade in
//                Text(grade).tag(grade)
//            }
//        }
        Text("")
    }
}

#Preview {
    Workout_Modifier()
}
